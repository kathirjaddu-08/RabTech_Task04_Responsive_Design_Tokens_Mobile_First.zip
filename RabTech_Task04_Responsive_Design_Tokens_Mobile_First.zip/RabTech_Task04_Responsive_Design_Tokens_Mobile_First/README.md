# RabTech Academy – Task 04
## Responsive Design Tokens & Mobile-First CSS Architecture

### Requirements covered
- CSS custom-property design tokens in `:root`
- Brand, typography, spacing, radius and surface variables
- Responsive multi-column dashboard
- Breakpoints for 320px, 480px, 768px and 1024px+
- Mobile-first responsive behaviour
- Glassmorphism/backdrop blur
- Soft shadows and hover/focus interactions
- Light/dark theme variables
- No intentional horizontal scrolling at mobile widths

### Files
```text
RabTech_Task04_Responsive_Design_Tokens_Mobile_First/
├── index.html
├── css/
│   └── style.css
├── js/
│   └── app.js
└── README.md
```

### Test
Open `index.html` in a browser and use responsive/device mode at:
- 320px
- 768px
- 1024px
- 1440px

Confirm the layout remains usable and there is no horizontal scrollbar at mobile widths.
