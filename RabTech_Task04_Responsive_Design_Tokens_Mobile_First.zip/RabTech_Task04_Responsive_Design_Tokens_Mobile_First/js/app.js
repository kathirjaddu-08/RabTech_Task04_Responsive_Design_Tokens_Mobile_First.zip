const toggle = document.querySelector("#themeToggle");
const root = document.documentElement;

toggle.addEventListener("click", () => {
  const dark = root.getAttribute("data-theme") === "dark";
  root.setAttribute("data-theme", dark ? "light" : "dark");
  toggle.setAttribute("aria-label", dark ? "Switch to dark theme" : "Switch to light theme");
});
